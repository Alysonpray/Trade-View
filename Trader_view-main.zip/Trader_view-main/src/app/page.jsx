import Dashboard from "../page/Dashboard";

export default function Home() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}